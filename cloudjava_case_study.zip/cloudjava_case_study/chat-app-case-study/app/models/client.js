var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var ClientSchema = new Schema({
	userid: { type: String, required: true, index: { unique: true }},
    socketid: { type: String, required: true, index: { unique: true }},
    status: String
});

module.exports = mongoose.model('Client', ClientSchema);

