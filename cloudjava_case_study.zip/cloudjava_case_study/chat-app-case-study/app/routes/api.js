var User = require('../models/user.js');

module.exports = function(app, express, io) {
	var api = express.Router();
	var userid;

	io.on('connection', function(socket){

		var userConnected = {
			userid: socket.request.session.user.userid,
			socketid: socket.id,
			status: 'Online'
		};

		User.update({userid: userConnected.userid}, userConnected).exec();
		io.emit('login',userConnected.userid);

		socket.on('chat-message', function(msg){
			var parseMsg = {
				message: msg.message,
				userid: msg.id
			};

			if (msg.recipients.length > 0) {
				msg.recipients.forEach(function(recipient) {
					User.findOne({userid: recipient })
						.select('socketid').exec(function(err, user){
							io.to(user.socketid).emit('server-chat-message',parseMsg);
						});
				});
			}
		});

		socket.on('disconnect', function(){
			var userDisconnected = {
				userid: socket.request.session.user.userid,
				status: 'Offline'
			};

			User.update({userid: userDisconnected.userid}, userDisconnected).exec();
			//io.emit('logout',userDisconnected.userid);
			socket.broadcast.emit('logout',userDisconnected.userid);
		});

		socket.on('update-status', function(msg){
			socket.broadcast.emit('update-status', msg);
			User.update({userid: msg.id}, {status: msg.newstatus}).exec();
		});

	});

	api.post('/authenticate', function(req, res){
		User.findOne({userid: req.body.username})
			.select('_id userid password fullname')
			.exec(function(err, user){

				if(err) throw err;

				if (!user) {

					res.json({
						success: false,
						message: "User doesn't exist."
					});
				} else {
					var validPassword = user.comparePassword(req.body.password);

					if(!validPassword) {
						res.json({
							success: false,
							message: "Invalid Password."
						});
					} else {
						req.session.regenerate(function(){
							req.session.user = user;
							res.json({
								success: true
							});
						});
					}
				}
			})
	});

	api.post('/signup', function(req, res){
		var user = new User({
			fullname : req.body.fullname,
			userid : req.body.userid,
			email : req.body.email,
			password : req.body.password
		});
		user.save(function(err){
			if(err){
				res.send(err);
				return;
			}

			req.session.regenerate(function(){
				io.emit('signedup', user.userid);
				req.session.user = user;
				res.json({
					success: true
				});
			});
		});

	});

	api.get('/users', function(req, res){

		if (req.session.user) {
			User.find({userid: { $ne: req.session.user.userid}}).select('userid status').exec(function(err, users) {
				if (err){
					res.send(err);
					return;
				}

				res.json(users);
			});
		} else {
			res.json({
				success: false
			});
		}
	});

	api.get('/checksession', function(req, res){
		if (req.session.user) {
			res.json({
				success: true,
				id: req.session.user.userid,
				fullname: req.session.user.fullname
			});
		} else {
			res.json({
				success: false
			});
		}
	});

	api.get('/logout', function(req, res){
		req.session.destroy(function(err) {
			if(err) throw err;
			res.json({
				success: true
			})
		});
	});

	return api;
};