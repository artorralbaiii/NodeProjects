var express = require('express');
var bodyParser = require('body-parser');
//var cookieParser = require('cookie-parser');
var cfenv = require('cfenv');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var appEnv = cfenv.getAppEnv();
var mongoose = require('mongoose');
var session = require('express-session');
var mongoStore = require('connect-mongo/es5')(session);

mongoose.connect('mongodb://admin:abc123@ds019698.mlab.com:19698/chat', function(err){
    if(err){
        console.log(err);
    } else {
        console.log('connected to the database');
    }
});

app.use(bodyParser.urlencoded({extended: false, keepExtensions: true}));
app.use(bodyParser.json());
//app.use(cookieParser());
app.use(express.static(__dirname + '/public'));

var sessionMiddleware = session({
    secret: 'SECRET',
    cookie: {maxAge: 60*60*1000},
    saveUninitialized: true,
    resave: true,
    store: new mongoStore({
        mongooseConnection: mongoose.connection})
});

//Share Socket and express session
io.use(function(socket, next) {
    sessionMiddleware(socket.request, socket.request.res, next);
});

app.use(sessionMiddleware);

var api = require('./app/routes/api.js')(app, express, io);
app.use('/api',api);

app.get('*', function(req, res){
    res.sendFile(__dirname + '/public/app/views/index.html');
});

http.listen(appEnv.port, '0.0.0.0', function() {
  console.log("server starting on " + appEnv.url);
});
