angular.module('appRoutes', ['ngRoute'])
	.config(function($routeProvider, $locationProvider){
		$routeProvider
			.when('/chatroom', {
				templateUrl: '/app/views/pages/chatroom.html',
				controller: 'ChatController',
				controllerAs: 'chat',
				resolve : {
					session : function(Auth){
						return Auth.isLoggedIn();
					}
				}
			})
			.when('/', {
				templateUrl: '/app/views/pages/login.html',
				controller: 'MainController',
				controllerAs: 'main'
			})
			.when('/signup', {
				templateUrl: '/app/views/pages/signup.html',
				controller: 'SignUpController',
				controllerAs: 'signup'
			})
			.otherwise({redirectTo:'/'});
			
		$locationProvider.html5Mode({
	            enabled: true,
	            requireBase: false
	    });
	});
	

	