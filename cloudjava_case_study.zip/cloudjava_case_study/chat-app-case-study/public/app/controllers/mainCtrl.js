angular.module('mainCtrl',[])
	.controller('MainController', function(Auth, $location){

		var vm = this;
		vm.loginData = {};
		vm.hasError = false;
		
		vm.doLogin = function() {
			vm.hasError = false;
			Auth.login(vm.loginData.username, vm.loginData.password)
				.success(function(data){
					if(data.success) {
						$location.path('/chatroom');
					} else {
						vm.error = data.message;
						vm.hasError = true;
					}
			});
		};

	});