angular.module('signUpCtrl', [])
	.controller('SignUpController', function(SignUp, $location){

		var vm = this;
		vm.userData={};
		vm.hasError = false;

		vm.signUp = function(){

			if (vm.userData.password != vm.userData.confirm_password) {
				vm.hasError = true;
				vm.message = "Passwords Don't Match.";
				return;
			} 

			SignUp.signUp(vm.userData)
				.success(function(data){
					if(data.success) {
						vm.hasError = false;
						vm.message = '';
						$location.path('/chatroom');
					} else {
						vm.hasError = true;
						if(data.errmsg) {
							vm.message = data.errmsg;
						} else {
							vm.message = data.message;
						}
						
					}
				});
		}
	});