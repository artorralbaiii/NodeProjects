angular.module('chatCtrl',[])
.controller('ChatController', function(Chat, Auth, $location, session){
	var vm = this;
	vm.message = '';
	var socket;
	vm.users = [];
	vm.clientRecipients = [];
	vm.fullname = '';
	vm.userid = '';
	vm.loggedIn = false;
	vm.currentStatus = 'Online';
	vm.oldStatus = 'Busy';
	vm.currentStatusIndicator = 'success';

	if (session.data.success) {
		vm.loggedIn = true;
		socket = io();
		vm.userid = session.data.id;
		vm.fullname = session.data.fullname;
	} else {
		$location.path('/');
	}

	Auth.allUsers()
	.then(function(data){
		vm.users = data.data;
	});

	vm.doLogout = function(){
		Auth.logout()
		.then(function(data){
			if (data.data.success){
				$location.path('/');
			}
		});
	};

	vm.sendMessage = function(){

		if (vm.clientRecipients.length < 1) {
			alert("Please choose a user you want to chat with.");
			return;
		}

		socket.emit('chat-message', {
			id: session.data.id,
			message: vm.message,
			recipients: vm.clientRecipients} );


		angular.element($("#chat-messages"))
		.append('<p><b>' + session.data.id + '</b> : ' +  vm.message + '</p>');
		vm.message = '';

		$("#chat-messages").scrollTop($('#chat-messages').prop('scrollHeight'));
	};

	vm.keyPress = function($event) {
		var keyCode = $event.which || $event.keyCode;

		if (keyCode === 13) {
			vm.sendMessage();
		}

	};

	vm.connectTo = function(user) {
		if (vm.clientRecipients.indexOf(user.userid) < 0) {
			angular.element($("#active-user"))
			.append('<span onClick="removeUser({userid: \'' + user.userid + '\'});" id="au-' + user.userid + '" class="btn badge badge-primary badge-btn">' + user.userid + ' <span class=" glyphicon glyphicon-remove"></span></span>');
			vm.clientRecipients.push(user.userid);
		}
	};

	connectToJS = function(user) {
		if (vm.clientRecipients.indexOf(user.userid) < 0) {
			angular.element($("#active-user"))
			.append('<span onClick="removeUser({userid: \'' + user.userid + '\'});" id="au-' + user.userid + '" class="btn badge badge-primary badge-btn">' + user.userid + ' <span class=" glyphicon glyphicon-remove"></span></span>');
			vm.clientRecipients.push(user.userid);
		}
	};

	vm.updateStatus = function() {
		if(vm.oldStatus==='Busy') {
			vm.currentStatusIndicator = 'danger';
			vm.currentStatus = 'Busy';
			vm.oldStatus = 'Online';
		} else {
			vm.currentStatusIndicator = 'success';
			vm.currentStatus = 'Online';
			vm.oldStatus = 'Busy';
		}

		socket.emit('update-status', {
			id: session.data.id,
			newstatus: vm.currentStatus,
			oldstatus: vm.oldStatus} );
	}

	removeUser = function(user){
		angular.element($("#au-" + user.userid)).remove();
		vm.clientRecipients.splice(vm.clientRecipients.indexOf(user.userid),1);
	};


	socket.on('server-chat-message', function(msg){
		angular.element($("#chat-messages"))
		.append('<p><b>' + msg.userid + '</b> : ' +  msg.message + '</p>');

		vm.connectTo(msg);
	});

	socket.on('signedup', function(msg){
		angular.element($("#contacts div"))
		.append('<a id="id-' + msg + '" onClick="connectToJS({userid:\'' + msg + '\'});" href="#" class="list-group-item Online">' + msg + '</a>' );
	});

	socket.on('logout', function(msg){
		angular.element($("#id-" + msg)).removeClass( "Online Busy" ).addClass( "Offline" );

	});

	socket.on('login', function(msg){
		angular.element($("#id-" + msg)).removeClass( "Offline Busy" ).addClass( "Online" );
	});

	socket.on('update-status', function(msg){
		angular.element($("#id-" + msg.id)).removeClass( msg.oldstatus + " Offline" ).addClass( msg.newstatus );
	});

});