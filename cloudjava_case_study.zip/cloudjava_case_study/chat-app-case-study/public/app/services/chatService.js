angular.module('chatService',[])
	.factory('Chat', function(){
		var chatFactory = {};


		return chatFactory;
	});