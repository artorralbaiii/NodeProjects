angular.module('signUpService',[])
	.factory('SignUp', function($http){
		signUpFactory = {};

		signUpFactory.signUp = function(user) {
			return $http.post('/api/signup', user);
		};


		return signUpFactory;
	});