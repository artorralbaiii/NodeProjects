angular.module('authService',[])
	.factory('Auth', function($http){

		var userFactory ={};

		userFactory.login = function(username, password) {
			return $http.post('/api/authenticate',{
				username: username,
				password: password
			});
		};

		userFactory.isLoggedIn = function(){
			return $http.get('/api/checksession');
		};

		userFactory.logout = function() {
			return $http.get('/api/logout');
		};

		userFactory.allUsers = function(){
			return $http.get('/api/users');
		}

		return userFactory;

	});