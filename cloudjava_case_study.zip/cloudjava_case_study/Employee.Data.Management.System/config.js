module.exports = {
	"database" : "mongodb://admin:abc123@ds059195.mongolab.com:59195/edms",
	"port": process.env.PORT || 3000,
	"secretKey": "MySecretKey"
}