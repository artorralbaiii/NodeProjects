var mongoose = require('mongoose');
var bcrypt = require('bcrypt-nodejs');
var Schema = mongoose.Schema;

var EmployeeSchema = new Schema({
    firstname: String,
    lastname: String,
    email: String,
    username: { type: String, required: true, index: { unique: true }},
    password: { type: String, required: true, select: false},
    role: String
});

EmployeeSchema.pre('save', function(next){
    var employee = this;
    if(!employee.isModified('password')) return next();

    bcrypt.hash(employee.password, null, null, function(err, hash){
        if(err) return next(err);

        employee.password = hash;
        next();
    });
});

EmployeeSchema.methods.comparePassword = function(password){
    var employee = this;
    return bcrypt.compareSync(password, employee.password);
};

module.exports = mongoose.model('Employee', EmployeeSchema);

