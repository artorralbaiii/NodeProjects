var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var AuditSchema = new Schema({

	comments: String,
	username: String,
	employeeid: {type: Schema.Types.ObjectId, fef: 'Employee', required: true},
	timestamp: {type: Date, default: Date.now}

});

module.exports = mongoose.model('Audit', AuditSchema);
