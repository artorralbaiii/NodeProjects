var Employee = require('../models/employee.js');
var Audit = require('../models/audit.js');
var config = require('../../config.js');
var multer = require('multer');
var path = require('path');
var crypto = require('crypto');
var xlsx = require('node-xlsx');
var jsonwebtoken = require('jsonwebtoken');
var fs = require('fs');
var bcrypt = require('bcrypt-nodejs');

var secretKey = config.secretKey;

function createToken(employee){
    var token = jsonwebtoken.sign({
        id: employee._id,
        username: employee.username,
        role: employee.role
    }, secretKey, {
        expiresInMinute: 1440
    });

    return token;
}

var storage = multer.diskStorage({
  destination: './uploads/',
  filename: function (req, file, cb) {
    crypto.pseudoRandomBytes(16, function (err, raw) {
      if (err) return cb(err)
      cb(null, raw.toString('hex') + path.extname(file.originalname))
    })
  }
});

var upload = multer({ storage: storage });

function auditLog(id, username, comments){

	var audit = new Audit({
		employeeid: id,
		username: username,
		comments: comments
	});

	audit.save(function(err){
		if(err) throw err;
	});
};

module.exports = function(app, express){
	var api = express.Router();

	api.post('/authenticate', function(req, res){
		Employee.findOne({username : req.body.username})
			.select('_id username role password').exec(function(err, employee){

				if(err) throw err;

				if(!employee){
					res.json({
						success: false,
						message: "User doesn't exist."
					});
				} else {
					var validPassword = employee.comparePassword(req.body.password);

					if(!validPassword){
						//Audit Trail
						auditLog(employee._id, employee.username, 'Trying to login. Password is invalid.');
						res.json({
							success: false,
							message: "Invalid password."
						});
					} else {
						//Audit Trail
						auditLog(employee._id, employee.username, 'Successfully logged in.');

						var token = createToken(employee);
						res.json({
							success: true,
							message: "Login successful.",
							token: token,
							name: employee.firstname
						});
					}
				}
		});
	});

	api.post('/employee/create', function(req, res){ // Sign Up

		var employee = new Employee({
			firstname : req.body.firstname,
			lastname : req.body.lastname,
			email : req.body.email,
			username : req.body.username,
			password : req.body.password
		});

		var token = createToken(employee);

		employee.save(function(err){ 
			if(err){
				res.send(err);
				return;
			}
			res.json({
				success : true,
				message : 'Employee successfully created',
				token: token,
				name: employee.firstname 
			});
		});
	}); // Sign Up


	api.get('/audit/export/:id', function(req, res){

		Employee.findOne({'_id' : req.params.id}, function(err, employee){
			if (err) {
				res.send(err);
				return;
			} else {
				if(employee.role != 'admin') {
					res.send('Not Authorized to perform this operation');
					return;
				}
			}
		});

		Audit.find({}, function(err, audits){
			if (err){
				res.send(err);
				return;
			}

			var data = [['Timestamp', 'Username' ,'Comments']];

		    for(var i=0;i<audits.length;i++){
		        var obj = audits[i];
		        var tmpArr = [obj.timestamp, obj.username, obj.comments];

		        data.push(tmpArr);

		    }

			var xlsx = require('node-xlsx');
			var xlBuffer = xlsx.build([{name: "Audits", data: data}]); // returns a buffer

			 res.writeHead(200, {
			   'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
			   'Content-Disposition': 'attachment; filename=audits.xlsx',
			   'Content-Length': xlBuffer.length
			 });

			res.end(xlBuffer);

		});
	});


	api.use(function(req, res, next){

        var token = req.query['x-access-token'] || req.headers['x-access-token'];

        // check if token exist
        if(token){
            jsonwebtoken.verify(token, secretKey, function(err, decoded){
                if(err){
                    res.status(403).send({success: false, message: "Failed to authenticate user"});
                } else {
                    req.decoded = decoded;
                    next();
                }
            });
        } else {
            res.status(403).send({success: false, message: "No token Provided"});
        }

    });

    api.get('/employee', function(req, res){	// Employees
		Employee.find({username: { $ne: 'admin' } }, function(err, employees){
			if (err){
				res.send(err);
				return;
			}

			res.json(employees);
		});
	}); // Employees

	api.get('/employee/get/:id', function(req, res){

		Employee.findOne({'_id' : req.params.id}, function(err, employee){
			if (err){
				res.send(err);
				return;
			}

			res.json(employee);
		});
	});

	api.post('/employee/update/:id', function(req, res){
		Employee.findOne({'_id' : req.params.id}, function(err, employee){
			if (err){
				res.send(err);
				return;
			}

			employee.firstname = req.body.firstname;
			employee.lastname = req.body.lastname;
			employee.email = req.body.email;
			employee.save();

			res.json({
				success : true,
				message : 'Profile successfully updated.',
				employee : employee
			});
		});
	});

	api.post('/employee/delete/:id', function(req, res){
		Employee.remove({'_id' : req.params.id}, function(err){
			if(err){
				res.send(err);
				return;
			}

			res.json({
				success : true,
				message : 'Employee successfully deleted.'
			});
		});
	});

	api.post('/employee/change_password/:id', function(req, res){
		Employee.findOne({'_id' : req.params.id}, function(err, employee){
			if (err){
				res.send(err);
				return;
			}

			employee.password = req.body.new_password;
			employee.save();
			//Audit Trail
			auditLog(employee._id, employee.username, 'Changed password.');

			res.json({
				success : true,
				message : 'Password successfully changed.'
			});
		});
	});

	api.post('/employee/import',upload.single('xl'), function(req, res){

		var obj = xlsx.parse(req.file.path); // parses a file
		var arr_employees = obj[0].data;
		var employees = [];

		for (var i = 1; i < arr_employees.length; i++) {
    		var tmp_obj= {
    			'firstname': arr_employees[i][0],
    			'lastname': arr_employees[i][1],
    			'email': arr_employees[i][2],
    			'username': arr_employees[i][3],
    			'password' :  bcrypt.hashSync('123456')
    		};

    		employees.push(tmp_obj);
		}

		Employee.collection.insert(employees, onInsert);
		fs.unlinkSync(req.file.path);
		function onInsert(err, records) {
		    if (err) {
				res.send(err);
				return;
		    } else {
		        res.json({
		        	success: true,
		        	message: 'Employees successfully imported.'
		        });
		    }
		};

	});


	api.get('/audit', function(req, res){
		Audit.find({}, function(err, audits){
			if (err){
				res.send(err);
				return;
			}

			res.json(audits);
		});
	});

    api.get('/curruser', function(req, res){
        res.json(req.decoded);
    });


	//Not use at the moment
	api.get('/audit/get/:user', function(req, res){
		Audit.find({employeeid: req.params.user}, function(err, audit){

			if(err){
				res.send(err);
				return;
			}

			res.json(audit);
		});
	});

	return api;
}
