angular.module('mainCtrl', [])
    .controller('MainController', function($rootScope, $location, Auth, AuthToken){

        var vm = this;

        vm.name = AuthToken.getName();
        vm.loggedIn = Auth.isLoggedIn();
        vm.admin = false;
        $rootScope.$on('$routeChangeStart', function(){
            vm.loggedIn = Auth.isLoggedIn();
            vm.name = AuthToken.getName();
            Auth.getUser()
                .then(function(data){
                    vm.user = data.data;
                    if (data.data.role == 'admin') {
                        vm.admin = true;
                    } else {
                        vm.admin = false;
                    }

                });
        });

        vm.doLogin = function(){
            vm.processing = true;
            vm.error = '';
            vm.hasError = false;

            Auth.login(vm.loginData.username, vm.loginData.password)

                .success(function(data){
                    vm.processing = false;

                    Auth.getUser()
                        .then(function(data){
                            vm.user = data.data;
                        });

                    if(data.success){
                        $location.path('/dashboard');
                    } else {
                        vm.error = data.message;
                        vm.hasError = true;
                    }
                });
        };

        vm.doLogout = function(){
            Auth.logout();
            $location.path('logout');
        };

    });
