angular.module('importCtrl',[])
	.controller('ImportController', function(FileUpload, AuthToken){
		var vm = this;

		vm.importData = {};

		if(!AuthToken.getToken()) {
			$location.path('/login');
		}

		angular.element($("#error")).css( "display", "none" ); 
		angular.element($("#success")).css( "display", "none" ); 

        vm.uploadFile = function(){
               var file = vm.importData;
               vm.message = '';
               angular.element($("#error")).css( "display", "none" ); 

               FileUpload.upload(file)
               	.success(function(data){

					if (data.success) {
						$("#success").fadeIn();
						$("#success").fadeOut(3000);
						vm.message = data.message;
					} else {
						$("#error").fadeIn();
						vm.message = data.errmsg;
					}

               	});
        };
	});