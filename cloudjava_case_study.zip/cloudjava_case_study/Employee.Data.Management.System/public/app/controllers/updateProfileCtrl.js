angular.module('updateProfileCtrl',[])
	.controller('UpdateProfileController', function($location, $scope, $routeParams, UpdateProfile, AuthToken, Auth){
		var vm = this;

		if(!AuthToken.getToken()) {
			$location.path('/login');
		}

		vm.success = false;
		vm.error = false;

		angular.element($("#error")).css( "display", "none" ); 
		angular.element($("#success")).css( "display", "none" ); 

    	UpdateProfile.getProfile($routeParams.id)
     		.success(function(employee){
     			vm.empData = employee;	
    	});

		vm.editable = function(state){
			angular.element($("#firstname")).prop( "disabled", state ); 
			angular.element($("#lastname")).prop( "disabled", state ); 
			angular.element($("#email")).prop( "disabled", state ); 
			vm.readMode = state;
		};

		vm.editable(true);

		vm.updateProfile = function(){
			UpdateProfile.updateProfile($routeParams.id, vm.empData)
				.success(function(data){

					vm.message = data.message;

					if(data.success){
						$("#success").fadeIn();
						$("#success").fadeOut(3000);
						AuthToken.setToken('name',data.employee.firstname + ' ' + data.employee.lastname );
						vm.empData = data.employee;	
					} else {
						$("#error").fadeIn();
						$("#error").fadeOut(3000);
					}
				});
		};

		vm.back = function(){
			if($routeParams.opener == 0) {
				$location.path('dashboard');
			} else {
				$location.path('employees');
			}
		}


	});