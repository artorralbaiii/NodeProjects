angular.module('dashboardCtrl',[])
	.controller('DashboardController', function($location, AuthToken){

		var vm = this;

		if(!AuthToken.getToken()) {
			$location.path('/login');
		}

		vm.user = AuthToken.getName();

	});