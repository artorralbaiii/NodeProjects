angular.module('employeesCtrl',[])
	.controller('EmployeesController', function($location, AuthToken, Employees ){
		var vm = this;
		vm.employees = [];
		vm.currentPage = 1;
		vm.pageSize = 10;

		if(!AuthToken.getToken()) {
			$location.path('/login');
		}
		//$scope.$parent.parentTag
		vm.parentTag = 'Employees';
		angular.element($("#error")).css( "display", "none" ); 
		angular.element($("#success")).css( "display", "none" ); 

		getAllEmployees();

		function getAllEmployees() {
			Employees.allEmployees()
				.then(function(data){
					vm.employees = data.data;
			});
		}

		vm.delete = function(id){
			Employees.delete(id)
				.then(function(data){
					vm.message = data.data.message;

					if (data.data.success) {
						$("#success").fadeIn();
						$("#success").fadeOut(3000);
						getAllEmployees();
					} else {
						$("#error").fadeIn();
						$("#error").fadeOut(3000);
					}

			});
		};

	});