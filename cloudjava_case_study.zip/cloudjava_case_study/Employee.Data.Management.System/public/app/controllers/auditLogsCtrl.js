angular.module('auditLogsCtrl',[])
	.controller('AuditLogsController', function(AuditLogs, Auth, AuthToken, $window){
		var vm = this;

		vm.auditLogs = [];
		vm.pageSize = 10;
		vm.currentPage = 1;

		if(!AuthToken.getToken()) {
			$location.path('/login');
		}

		 AuditLogs.auditLogs()
		 	.success(function(data){
		 		vm.auditLogs = data;
		 });

		 vm.export = function(){
		     Auth.getUser()
	            .then(function(data){
	                $window.open('/api/audit/export/' + data.data.id,'_self');
	            });
		 };

		 vm.download = function(){
		 	AuditLogs.download();
		 }
	});