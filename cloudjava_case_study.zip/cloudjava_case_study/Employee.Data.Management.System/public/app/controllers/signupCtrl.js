angular.module('signupCtrl',[])
	.controller('SignupController', function(Signup, $location, AuthToken){

		var vm = this;

		vm.signup = function() {
			vm.hasError = false;
			vm.message = '';

			if (vm.data.password != vm.data.confirm_password) {
				vm.hasError = true;
				vm.message = "Passwords Don't Match.";
				return;
			} 

			Signup.signup(vm.data)
				.success(function(data){
					if (data.success) {
						AuthToken.setToken('token',data.token);
						AuthToken.setToken('name',data.name);
						$location.path('/dashboard');
					} else {
						vm.message = data.message;
						vm.hasError = true;
					}
				});

		};	
	});