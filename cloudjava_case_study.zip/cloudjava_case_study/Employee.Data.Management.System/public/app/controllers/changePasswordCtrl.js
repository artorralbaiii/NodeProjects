angular.module('changePasswordCtrl',[])
	.controller('ChangePasswordController', function(Auth, AuthToken, ChangePassword){

		var vm = this;

		if(!AuthToken.getToken()) {
			$location.path('/login');
		}

		Auth.getUser()
            .then(function(data){
                vm.user = data.data;
            });

        angular.element($("#error")).css( "display", "none" ); 
		angular.element($("#success")).css( "display", "none" ); 



		vm.changePassword = function() {

			if (vm.changedData.new_password != vm.changedData.confirm_password) {
				vm.message = "Passwords Don't Match.";
				$("#error").fadeIn();
				$("#error").fadeOut(3000);
				return;
			} 

			ChangePassword.changePassword(vm.user.id, vm.changedData)
				.success(function(data){

					vm.message = data.message;

					if (data.success) {
						$("#success").fadeIn();
						$("#success").fadeOut(3000);
					} else {
						$("#error").fadeIn();
						$("#error").fadeOut(3000);
					}

					vm.changedData = '';

				});
		}
	});