angular.module('appRoutes', ['ngRoute'])
	.config(function($routeProvider, $locationProvider){
		$routeProvider
			.when('/', {
				templateUrl: '/app/views/pages/home.html',
				controller: 'MainController',
				controllerAs: 'main'
			}).when('/login', {
				templateUrl: '/app/views/pages/login.html',
				controller: 'MainController',
				controllerAs: 'main'
			}).when('/dashboard', {
				templateUrl: '/app/views/pages/dashboard.html',
				controller: 'DashboardController',
				controllerAs: 'dashboard'
			}).when('/profile/:opener/:id', {
				templateUrl: '/app/views/pages/updateProfile.html',
				controller: 'UpdateProfileController',
				controllerAs: 'profile'
			}).when('/signup', {
				templateUrl: '/app/views/pages/signup.html',
				controller: 'SignupController',
				controllerAs: 'signup'
			}).when('/change_password', {
				templateUrl: '/app/views/pages/changePassword.html',
				controller: 'ChangePasswordController',
				controllerAs: 'password'
			}).when('/employees', {
				templateUrl: '/app/views/pages/employeeProfiles.html',
				controller: 'EmployeesController',
				controllerAs: 'employees'
			}).when('/import', {
				templateUrl: '/app/views/pages/importEmployees.html',
				controller: 'ImportController',
				controllerAs: 'import'
			}).when('/auditlogs', {
				templateUrl: '/app/views/pages/auditLogs.html',
				controller: 'AuditLogsController',
				controllerAs: 'auditLog'
			}).when('/logout',{redirectTo:'/login'})
			.otherwise({redirectTo:'/'});
			
		$locationProvider.html5Mode({
	            enabled: true,
	            requireBase: false
	    });
	});
	

	