angular.module('MyApp',['appRoutes', 'ui.bootstrap', 'mainCtrl', 'authService','dashboardCtrl',
						'updateProfileService','updateProfileCtrl','signupService','signupCtrl',
						'changePasswordService','changePasswordCtrl','employeesService','employeesCtrl',
						'importService','importCtrl','fileModel','auditLogsService','auditLogsCtrl'])
	.config(function($httpProvider){
		$httpProvider.interceptors.push('AuthInterceptor');
	})
	.filter('startFrom', function(){
		return function(data, start){
			return data.slice(start);
		}
	}); 