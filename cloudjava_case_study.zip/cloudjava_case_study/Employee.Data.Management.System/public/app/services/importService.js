angular.module('importService',[])
	.factory('FileUpload', function($http){
		var fileUploadFactory = {};

		fileUploadFactory.upload = function(file){
          var fd = new FormData();
           fd.append('xl', file.xl);
        
           return $http.post('/api/employee/import', fd, {
              transformRequest: angular.identity,
              headers: {'Content-Type': undefined}
           });
		};

		return fileUploadFactory;
	});