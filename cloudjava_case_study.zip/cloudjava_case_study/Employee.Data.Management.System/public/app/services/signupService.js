angular.module('signupService',[])
	.factory('Signup', function($http){
		var signupFactory = {};

		signupFactory.signup = function(employee){
			return $http.post('/api/employee/create', employee)
		};

		return signupFactory;
	});