angular.module('auditLogsService',[])
	.factory('AuditLogs', function($http, $q, $timeout, $window){
		var auditLogFactory = {};

		auditLogFactory.auditLogs = function(){
			return $http.get('/api/audit');
		};

		auditLogFactory.export = function(){
			return $http.get('/api/audit/export');
		}

		return auditLogFactory;
	});