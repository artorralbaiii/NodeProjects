angular.module('changePasswordService',[])
	.factory('ChangePassword', function($http){

		var changePasswordFactory = {};

		changePasswordFactory.changePassword = function(id, changedData){
			return $http.post('/api/employee/change_password/' + id, changedData);
		}

		return changePasswordFactory;

	});