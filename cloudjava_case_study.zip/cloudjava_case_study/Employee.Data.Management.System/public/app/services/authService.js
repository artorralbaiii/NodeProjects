angular.module('authService', [])
	.factory('Auth', function($http, $q, AuthToken){
		var authFactory = {};

		authFactory.login = function(username, password) {
			return $http.post('/api/authenticate', {
				username: username,
				password: password
			})
			.success(function(data){
				AuthToken.setToken('token',data.token);
				AuthToken.setToken('name',data.name);
				return data;
			});
		};

		authFactory.logout = function(){
			AuthToken.setToken('token');
			AuthToken.setToken('name');
		};

		authFactory.isLoggedIn = function(){
			if(AuthToken.getToken()){
				return true;
			} else {
				return false;
			}
		};

        authFactory.getUser = function(){
            if(AuthToken.getToken()){
                return $http.get('/api/curruser');
            } else {
                return $q.reject({ message: "User has no token"});
            }
        };

		return authFactory;

	})

	.factory('AuthToken', function($window){
		var authTokenFactory = {};

		authTokenFactory.getToken = function(){
			return $window.localStorage.getItem('token');
		};

		authTokenFactory.getName = function(){
			return $window.localStorage.getItem('name');
		};

		authTokenFactory.setToken = function(name, token){
			if(token){
				$window.localStorage.setItem(name, token);
			} else {
				$window.localStorage.removeItem(name);
			}
		};

		return authTokenFactory;

	})

	.factory('AuthInterceptor', function($q, $location, AuthToken){
		var interceptorFactory = {};

		interceptorFactory.request = function(config){
			var token = AuthToken.getToken();

			if(token){
				config.headers['x-access-token'] = token;
			}

			return config;
		};

		interceptorFactory.responseError = function(response){
			if(response.status == 403){
				$location.path('/login');
			}

			return $q.reject(response);
		};


		return interceptorFactory;
	});