angular.module('employeesService',[])
	.factory('Employees', function($http){

		var employeesFactory={};

		employeesFactory.allEmployees = function(){
			return $http.get('/api/employee');
		};

		employeesFactory.delete = function(id){
			return $http.post('/api/employee/delete/'+id);
		};

		return employeesFactory;

	});