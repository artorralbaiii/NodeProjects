angular.module('updateProfileService',[])
	.factory('UpdateProfile', function($http){
		var updateProfileFactory = {};

		updateProfileFactory.updateProfile = function(id, data){
			return $http.post('/api/employee/update/' + id, data);
		};

		updateProfileFactory.getProfile = function(id) {
			return $http.get('/api/employee/get/' + id);
		};

		return updateProfileFactory;
	});